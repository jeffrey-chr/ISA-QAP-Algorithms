#ifndef ACOTSP_ADAPTATION_H
#define ACOTSP_ADAPTATION_H
void adapt_parameters_init(void);
void adapt_parameters_next_iteration(void);

#endif
